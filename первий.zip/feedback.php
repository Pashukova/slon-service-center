<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);
    
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Введите имя';
    }
    
    if (empty($email)) {
        $errors[] = 'Введите email';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Неверный формат email';
    }
    
    if (empty($message)) {
        $errors[] = 'Введите сообщение';
    }
    
    if (empty($errors)) {
        // Здесь можно добавить отправку email администратору
        $to = 'info@slon-service.ru';
        $subject = 'Новое сообщение с сайта от ' . $name;
        $headers = "From: $email\r\n";
        $headers .= "Reply-To: $email\r\n";
        $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
        
        $emailBody = "Имя: $name\n";
        $emailBody .= "Email: $email\n\n";
        $emailBody .= "Сообщение:\n$message";
        
        mail($to, $subject, $emailBody, $headers);
        
        echo json_encode(['success' => true, 'message' => 'Сообщение отправлено успешно']);
        exit;
    }
    
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}
?>