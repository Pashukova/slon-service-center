<?php
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Необходима авторизация']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $deviceType = trim($_POST['device_type']);
    $model = trim($_POST['model']);
    $imei = trim($_POST['imei']);
    $purchaseDate = trim($_POST['purchase_date']);
    
    $errors = [];
    
    if (empty($deviceType)) {
        $errors[] = 'Выберите тип устройства';
    }
    
    if (empty($model)) {
        $errors[] = 'Введите модель устройства';
    }
    
    if (empty($errors)) {
        // Добавляем устройство
        $stmt = $pdo->prepare("INSERT INTO user_devices (user_id, device_type, model, imei, purchase_date) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$userId, $deviceType, $model, $imei, $purchaseDate ? $purchaseDate : null]);
        
        echo json_encode(['success' => true, 'message' => 'Устройство успешно добавлено']);
        exit;
    }
    
    echo json_encode(['success' => false, 'message' => implode('<br>', $errors)]);
    exit;
}
?>