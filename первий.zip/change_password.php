<?php
require_once 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Необходима авторизация']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_SESSION['user_id'];
    $currentPassword = trim($_POST['current_password']);
    $newPassword = trim($_POST['new_password']);
    $confirmNewPassword = trim($_POST['confirm_new_password']);
    
    $errors = [];
    
    if (empty($currentPassword)) {
        $errors[] = 'Введите текущий пароль';
    }
    
    if (empty($newPassword)) {
        $errors[] = 'Введите новый пароль';
    } elseif (strlen($newPassword) < 6) {
        $errors[] = 'Пароль должен содержать минимум 6 символов';
    }
    
    if ($newPassword !== $confirmNewPassword) {
        $errors[] = 'Новые пароли не совпадают';
    }
    
    if (empty($errors)) {
        // Проверяем текущий пароль
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($currentPassword, $user['password'])) {
            // Обновляем пароль
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);
            
            echo json_encode(['success' => true, 'message' => 'Пароль успешно изменен']);
            exit;
        } else {
            $errors[] = 'Неверный текущий пароль';
        }
    }
    
    echo json_encode(['success' => false, 'message' => implode('<br>', $errors)]);
    exit;
}
?>