<?php
require_once 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['forgotEmail']);
    
    if (empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Введите email']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Неверный формат email']);
        exit;
    }
    
    // Проверяем, есть ли пользователь с таким email
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user) {
        // Генерируем токен для сброса пароля
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Сохраняем токен в базе
        $stmt = $pdo->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
        $stmt->execute([$email, $token, $expires]);
        
        // Отправляем email с ссылкой для сброса пароля
        $resetLink = "https://вашсайт.ru/reset_password.php?token=$token";
        
        $to = $email;
        $subject = 'Восстановление пароля для сервисного центра "Слон"';
        $message = "Здравствуйте, {$user['name']}!\n\n";
        $message .= "Для восстановления пароля перейдите по ссылке:\n";
        $message .= "$resetLink\n\n";
        $message .= "Ссылка действительна в течение 1 часа.\n";
        $message .= "Если вы не запрашивали восстановление пароля, проигнорируйте это сообщение.\n\n";
        $message .= "С уважением,\nСервисный центр \"Слон\"";
        
        $headers = "From: no-reply@slon-service.ru\r\n";
        
        mail($to, $subject, $message, $headers);
    }
    
    // Всегда возвращаем успех, даже если email не найден (для безопасности)
    echo json_encode(['success' => true, 'message' => 'Если email зарегистрирован, на него отправлена ссылка для восстановления пароля']);
    exit;
}
?>