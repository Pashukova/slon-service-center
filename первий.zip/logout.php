<?php
require_once 'config.php';

// Уничтожаем сессию
session_unset();
session_destroy();

// Перенаправляем на главную страницу
header('Location: index.html');
exit;
?>