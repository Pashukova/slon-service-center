<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['loginEmail']);
    $password = trim($_POST['loginPassword']);
    
    $errors = [];
    
    if (empty($email)) {
        $errors[] = 'Введите email';
    }
    
    if (empty($password)) {
        $errors[] = 'Введите пароль';
    }
    
    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            
            echo json_encode(['success' => true, 'message' => 'Вход выполнен успешно!']);
            exit;
        } else {
            $errors[] = 'Неверный email или пароль';
        }
    }
    
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}
?>