<?php
require_once 'config.php';

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    header('Location: index.html');
    exit;
}

// Получаем данные пользователя
$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    session_destroy();
    header('Location: index.html');
    exit;
}

// Получаем заказы пользователя
$orders = [];
$stmt = $pdo->prepare("SELECT ro.*, s.name as service_name 
                       FROM repair_orders ro 
                       JOIN services s ON ro.service_id = s.id 
                       WHERE ro.user_id = ? 
                       ORDER BY ro.created_at DESC");
$stmt->execute([$userId]);
$orders = $stmt->fetchAll();

// Получаем устройства пользователя
$devices = [];
$stmt = $pdo->prepare("SELECT * FROM user_devices WHERE user_id = ?");
$stmt->execute([$userId]);
$devices = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет | Сервисный центр "Слон"</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Стили из вашего файла account.html */
    </style>
</head>
<body>
    <!-- Шапка -->
    <header>
        <div class="header-container">
            <a href="index.html">
                <img src="img/logo-white.png" alt="Сервисный центр Слон" class="logo">
            </a>
            <div class="contact-header">
                <a href="tel:+74236605245">
                    <i class="fas fa-phone"></i> +7 (4236) 60-52-45
                </a>
                <a href="index.html#contacts">
                    <i class="fas fa-map-marker-alt"></i> Находка
                </a>
                <a href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Выйти
                </a>
            </div>
        </div>
    </header>

    <!-- Навигация -->
    <nav>
        <div class="nav-container">
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            <ul class="nav-links" id="navLinks">
                <li><a href="index.html#services">Услуги</a></li>
                <li><a href="index.html#about">О нас</a></li>
                <li><a href="index.html#reviews">Отзывы</a></li>
                <li><a href="index.html#faq">FAQ</a></li>
                <li><a href="index.html#contacts">Контакты</a></li>
                <li><a href="#" id="openBookingModalNav">Записаться</a></li>
                <li><a href="account.php" class="active">Личный кабинет</a></li>
            </ul>
        </div>
    </nav>

    <!-- Личный кабинет -->
    <section class="account-section">
        <div class="account-container">
            <div class="account-sidebar">
                <ul class="account-nav">
                    <li><a href="#" class="active" data-tab="profile">Профиль</a></li>
                    <li><a href="#" data-tab="orders">Мои заявки</a></li>
                    <li><a href="#" data-tab="devices">Мои устройства</a></li>
                    <li><a href="#" data-tab="settings">Настройки</a></li>
                </ul>
            </div>
            
            <div class="account-content">
                <!-- Вкладка профиля -->
                <div class="account-tab" id="profileTab">
                    <div class="account-header">
                        <img src="img/user-avatar.jpg" alt="Аватар пользователя" class="account-avatar">
                        <div class="account-info">
                            <h2><?php echo htmlspecialchars($user['name']); ?></h2>
                            <p>Клиент с <?php echo date('d.m.Y', strtotime($user['created_at'])); ?></p>
                        </div>
                    </div>
                    
                    <div class="account-details">
                        <h3>Контактная информация</h3>
                        <div class="detail-item">
                            <strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?>
                        </div>
                        <div class="detail-item">
                            <strong>Телефон:</strong> <?php echo htmlspecialchars($user['phone']); ?>
                        </div>
                        <?php if (!empty($user['address'])): ?>
                        <div class="detail-item">
                            <strong>Адрес:</strong> <?php echo htmlspecialchars($user['address']); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Вкладка заявок -->
                <div class="account-tab" id="ordersTab" style="display: none;">
                    <h2>Мои заявки на ремонт</h2>
                    
                    <?php if (empty($orders)): ?>
                        <p>У вас пока нет заявок на ремонт.</p>
                    <?php else: ?>
                        <table class="orders-table">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Дата</th>
                                    <th>Услуга</th>
                                    <th>Описание</th>
                                    <th>Статус</th>
                                    <th>Стоимость</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td>#<?php echo htmlspecialchars($order['order_number']); ?></td>
                                    <td><?php echo date('d.m.Y', strtotime($order['created_at'])); ?></td>
                                    <td><?php echo htmlspecialchars($order['service_name']); ?></td>
                                    <td><?php echo !empty($order['problem_description']) ? htmlspecialchars($order['problem_description']) : '—'; ?></td>
                                    <td>
                                        <?php 
                                        $statusClass = '';
                                        $statusText = '';
                                        switch ($order['status']) {
                                            case 'pending':
                                                $statusClass = 'status-pending';
                                                $statusText = 'Ожидает';
                                                break;
                                            case 'in_progress':
                                                $statusClass = 'status-pending';
                                                $statusText = 'В работе';
                                                break;
                                            case 'completed':
                                                $statusClass = 'status-completed';
                                                $statusText = 'Завершено';
                                                break;
                                            case 'cancelled':
                                                $statusClass = 'status-cancelled';
                                                $statusText = 'Отменено';
                                                break;
                                        }
                                        ?>
                                        <span class="order-status <?php echo $statusClass; ?>"><?php echo $statusText; ?></span>
                                    </td>
                                    <td>
                                        <?php echo $order['price'] ? number_format($order['price'], 2, '.', ' ') . ' руб.' : '—'; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
                
                <!-- Вкладка устройств -->
                <div class="account-tab" id="devicesTab" style="display: none;">
                    <h2>Мои устройства</h2>
                    
                    <?php if (empty($devices)): ?>
                        <p>У вас пока нет добавленных устройств.</p>
                    <?php else: ?>
                        <div class="device-list">
                            <?php foreach ($devices as $device): ?>
                            <div class="device-card">
                                <div class="device-info">
                                    <h3><?php echo htmlspecialchars($device['device_type'] . ' ' . $device['model']); ?></h3>
                                    <p>Добавлено: <?php echo date('d.m.Y', strtotime($device['created_at'])); ?></p>
                                    <?php if (!empty($device['imei'])): ?>
                                    <p>IMEI: <?php echo htmlspecialchars($device['imei']); ?></p>
                                    <?php endif; ?>
                                </div>
                                <button class="btn-service">История ремонтов</button>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    
                    <button class="submit-btn" style="margin-top: 1.5rem;" id="addDeviceBtn">Добавить устройство</button>
                </div>
                
                <!-- Вкладка настроек -->
                <div class="account-tab" id="settingsTab" style="display: none;">
                    <h2>Настройки аккаунта</h2>
                    
                    <form id="accountSettingsForm" action="update_profile.php" method="POST">
                        <div class="form-group">
                            <label for="settingsName">Имя</label>
                            <input type="text" id="settingsName" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="settingsEmail">Email</label>
                            <input type="email" id="settingsEmail" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="settingsPhone">Телефон</label>
                            <input type="tel" id="settingsPhone" name="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="settingsAddress">Адрес</label>
                            <input type="text" id="settingsAddress" name="address" class="form-control" value="<?php echo htmlspecialchars($user['address']); ?>">
                        </div>
                        
                        <button type="submit" class="submit-btn">Сохранить изменения</button>
                    </form>
                    
                    <div class="password-change" style="margin-top: 2rem;">
                        <h3>Смена пароля</h3>
                        <form id="passwordChangeForm" action="change_password.php" method="POST">
                            <div class="form-group">
                                <label for="currentPassword">Текущий пароль</label>
                                <input type="password" id="currentPassword" name="current_password" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="newPassword">Новый пароль</label>
                                <input type="password" id="newPassword" name="new_password" class="form-control" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="confirmNewPassword">Подтвердите новый пароль</label>
                                <input type="password" id="confirmNewPassword" name="confirm_new_password" class="form-control" required>
                            </div>
                            
                            <button type="submit" class="submit-btn">Изменить пароль</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Футер -->
    <footer>
        <!-- Футер из вашего файла account.html -->
    </footer>

    <!-- Модальное окно добавления устройства -->
    <div class="modal" id="addDeviceModal" style="display: none;">
        <div class="modal-content">
            <span class="close-modal" id="closeAddDeviceModal">&times;</span>
            <h2 class="modal-title">Добавить устройство</h2>
            
            <form id="addDeviceForm" action="add_device.php" method="POST">
                <div class="form-group">
                    <label for="deviceType">Тип устройства</label>
                    <select id="deviceType" name="device_type" class="form-control" required>
                        <option value="">Выберите тип</option>
                        <option value="iPhone">iPhone</option>
                        <option value="Samsung">Samsung</option>
                        <option value="Xiaomi">Xiaomi</option>
                        <option value="Huawei">Huawei</option>
                        <option value="Другое">Другое</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="deviceModel">Модель</label>
                    <input type="text" id="deviceModel" name="model" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="deviceImei">IMEI (необязательно)</label>
                    <input type="text" id="deviceImei" name="imei" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="devicePurchaseDate">Дата покупки (необязательно)</label>
                    <input type="date" id="devicePurchaseDate" name="purchase_date" class="form-control">
                </div>
                
                <button type="submit" class="submit-btn">Добавить устройство</button>
            </form>
        </div>
    </div>

    <script>
        // Мобильное меню
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const navLinks = document.getElementById('navLinks');
        
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');
        });

        // Переключение вкладок в личном кабинете
        const tabLinks = document.querySelectorAll('.account-nav a');
        const tabs = document.querySelectorAll('.account-tab');
        
        tabLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                
                // Убираем активный класс у всех ссылок
                tabLinks.forEach(l => l.classList.remove('active'));
                // Добавляем активный класс текущей ссылке
                link.classList.add('active');
                
                // Скрываем все вкладки
                tabs.forEach(tab => tab.style.display = 'none');
                // Показываем нужную вкладку
                const tabId = link.dataset.tab + 'Tab';
                document.getElementById(tabId).style.display = 'block';
            });
        });

        // Открытие модального окна добавления устройства
        document.getElementById('addDeviceBtn').addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('addDeviceModal').style.display = 'flex';
        });

        // Закрытие модального окна добавления устройства
        document.getElementById('closeAddDeviceModal').addEventListener('click', () => {
            document.getElementById('addDeviceModal').style.display = 'none';
        });

        // Обработка формы добавления устройства
        document.getElementById('addDeviceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch(this.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Устройство успешно добавлено!');
                    document.getElementById('addDeviceModal').style.display = 'none';
                    location.reload(); // Перезагружаем страницу для обновления списка устройств
                } else {
                    alert('Ошибка: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Произошла ошибка при отправке формы');
            });
        });

        // Обработка формы изменения профиля
        document.getElementById('accountSettingsForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch(this.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Изменения сохранены успешно!');
                    location.reload(); // Перезагружаем страницу для обновления данных
                } else {
                    alert('Ошибка: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Произошла ошибка при отправке формы');
            });
        });

        // Обработка формы смены пароля
        document.getElementById('passwordChangeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch(this.action, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Пароль изменен успешно!');
                    this.reset();
                } else {
                    alert('Ошибка: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Произошла ошибка при отправке формы');
            });
        });
    </script>
</body>
</html>