<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['bookingName']);
    $phone = trim($_POST['bookingPhone']);
    $email = trim($_POST['bookingEmail']);
    $service = trim($_POST['bookingService']);
    $date = trim($_POST['bookingDate']);
    $time = trim($_POST['bookingTime']);
    $message = trim($_POST['bookingMessage']);
    
    $errors = [];
    
    if (empty($name)) {
        $errors[] = 'Введите имя';
    }
    
    if (empty($phone)) {
        $errors[] = 'Введите телефон';
    }
    
    if (empty($email)) {
        $errors[] = 'Введите email';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Неверный формат email';
    }
    
    if (empty($service)) {
        $errors[] = 'Выберите услугу';
    }
    
    if (empty($date)) {
        $errors[] = 'Выберите дату';
    }
    
    if (empty($time)) {
        $errors[] = 'Выберите время';
    }
    
    if (empty($errors)) {
        // Проверяем, зарегистрирован ли пользователь
        $userId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
        
        // Получаем ID услуги
        $stmt = $pdo->prepare("SELECT id FROM services WHERE name = ?");
        $stmt->execute([$service]);
        $serviceId = $stmt->fetchColumn();
        
        if (!$serviceId) {
            $errors[] = 'Услуга не найдена';
        } else {
            // Формируем дату и время
            $appointmentDateTime = date('Y-m-d H:i:s', strtotime("$date $time"));
            
            // Генерируем номер заказа
            $orderNumber = 'SL' . date('Ymd') . str_pad(mt_rand(1, 9999), 4, '0', STR_PAD_LEFT);
            
            // Создаем заявку
            $stmt = $pdo->prepare("INSERT INTO repair_orders (user_id, service_id, order_number, problem_description, appointment_date, created_at) 
                                  VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$userId, $serviceId, $orderNumber, $message, $appointmentDateTime]);
            
            // Отправляем email уведомление (заглушка)
            // sendBookingEmail($email, $name, $orderNumber, $service, $appointmentDateTime);
            
            echo json_encode(['success' => true, 'message' => 'Ваша заявка принята! Номер заказа: ' . $orderNumber]);
            exit;
        }
    }
    
    echo json_encode(['success' => false, 'errors' => $errors]);
    exit;
}

// Функция для отправки email (заглушка)
function sendBookingEmail($email, $name, $orderNumber, $service, $dateTime) {
    $to = $email;
    $subject = 'Ваша заявка в сервисный центр "Слон"';
    $message = "Уважаемый(ая) $name,\n\n";
    $message .= "Ваша заявка на услугу \"$service\" принята.\n";
    $message .= "Номер вашей заявки: $orderNumber\n";
    $message .= "Дата и время приема: " . date('d.m.Y H:i', strtotime($dateTime)) . "\n\n";
    $message .= "С уважением,\nСервисный центр \"Слон\"";
    $headers = 'From: info@slon-service.ru';
    
    mail($to, $subject, $message, $headers);
}
?>